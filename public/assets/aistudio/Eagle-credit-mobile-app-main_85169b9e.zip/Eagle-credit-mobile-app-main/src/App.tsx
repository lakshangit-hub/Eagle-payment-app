import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Customer, Facility, ScreenType, Ledger, StoredPayment } from './types';
import { CUSTOMERS, INITIAL_FACILITIES, GUARANTORS, INITIAL_HISTORY } from './data/mockData';
import {
  accessVault,
  emptyLedger,
  confirmedAmount,
  reservedAmount,
  confirmQueued,
  recordAttempt,
  validatePaymentAmount,
} from './services/vault';
import { Header } from './components/Header';
import { SearchScreen } from './components/SearchScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { FacilityScreen } from './components/FacilityScreen';
import { GuarantorsScreen } from './components/GuarantorsScreen';
import { AssetScreen } from './components/AssetScreen';
import { HistoryScreen } from './components/HistoryScreen';
import { CollectScreen } from './components/CollectScreen';
import { ConfirmScreen } from './components/ConfirmScreen';
import { ConfirmModal } from './components/ConfirmModal';
import { ReceiptScreen } from './components/ReceiptScreen';
import { SyncStatusScreen } from './components/SyncStatusScreen';
import { playSuccessChime, playKeyClick } from './utils/audio';
import { Smartphone, Monitor } from 'lucide-react';

export default function App() {
  // Navigation
  const [screen, setScreen] = useState<ScreenType>('search');
  const [stack, setStack] = useState<ScreenType[]>([]);

  // Selection
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(CUSTOMERS[0].id);
  const [selectedFacilityNo, setSelectedFacilityNo] = useState<string>(INITIAL_FACILITIES[0].no);
  const [activeReceiptNo, setActiveReceiptNo] = useState<string | null>(null);

  // Form input
  const [amount, setAmount] = useState<string>('');
  const [amountError, setAmountError] = useState<string>('');
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);

  // Device Ledger Vault & Sync State
  const [ledger, setLedger] = useState<Ledger>(emptyLedger());
  const [ready, setReady] = useState<boolean>(false);
  const [connected, setConnected] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [syncing, setSyncing] = useState<boolean>(false);
  const [syncingIds, setSyncingIds] = useState<string[]>([]);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveError, setSaveError] = useState<string>('');
  const [syncFilter, setSyncFilter] = useState<'all' | 'pending' | 'synced'>('all');

  // Presentation: phone frame or responsive container
  const [phoneFrame, setPhoneFrame] = useState<boolean>(true);

  // Synchronize dynamic balances after confirmed payments
  const currentFacilities = useMemo(() => {
    return INITIAL_FACILITIES.map((f) => ({
      ...f,
      balance: Math.max(0, f.balance - confirmedAmount(ledger.payments, f.no)),
    }));
  }, [ledger.payments]);

  const currentCustomer = useMemo(() => {
    return CUSTOMERS.find((c) => c.id === selectedCustomerId) || CUSTOMERS[0];
  }, [selectedCustomerId]);

  const currentFacility = useMemo(() => {
    return (
      currentFacilities.find((f) => f.no === selectedFacilityNo) ||
      currentFacilities.find((f) => f.customerId === currentCustomer.id) ||
      currentFacilities[0]
    );
  }, [currentFacilities, selectedFacilityNo, currentCustomer.id]);

  const currentGuarantors = useMemo(() => {
    return GUARANTORS.filter((g) => g.customerId === currentCustomer.id);
  }, [currentCustomer.id]);

  // Push new screen to stack
  const navigateTo = useCallback((nextScreen: ScreenType) => {
    setStack((prev) => [...prev, screen]);
    setScreen(nextScreen);
    window.scrollTo(0, 0);
  }, [screen]);

  // Go back one screen
  const navigateBack = useCallback(() => {
    setStack((prev) => {
      if (prev.length === 0) {
        setScreen('search');
        return [];
      }
      const nextStack = [...prev];
      const previousScreen = nextStack.pop() || 'search';
      setScreen(previousScreen);
      return nextStack;
    });
    window.scrollTo(0, 0);
  }, []);

  // Save changes to encrypted device vault
  const saveToVault = useCallback(
    async (transform?: (curr: Ledger) => Ledger): Promise<boolean> => {
      try {
        const updated = await accessVault(transform);
        setLedger(updated);
        setSaveError('');
        return true;
      } catch (err) {
        console.error('Vault access failed:', err);
        setSaveError('Secure save failed. Device ledger is protected. Please reload.');
        return false;
      }
    },
    []
  );

  // Sync queued payments with server / backend
  const triggerSync = useCallback(async () => {
    if (!ready || syncing || ledger.manualOffline || !navigator.onLine) return;

    const pending = ledger.payments.filter((p) => p.status === 'Pending Sync');
    const ids = pending.map((p) => p.no);
    if (ids.length === 0) return;

    setSyncing(true);
    setSyncingIds(ids);

    const at = new Date().toISOString();

    try {
      // Step 1: Record attempt timestamp
      const ok = await saveToVault((c) => recordAttempt(c, ids, at));
      if (!ok) return;

      // Step 2: Simulated network transit time
      await new Promise((res) => setTimeout(res, 800));

      if (!navigator.onLine) {
        throw new Error('Connection lost during sync check');
      }

      setConnected(true);

      // Step 3: Confirm queued payments
      await saveToVault((c) => (c.manualOffline ? c : confirmQueued(c, ids)));
    } catch (err) {
      console.warn('Sync failed:', err);
      setConnected(false);
      await saveToVault((c) => ({
        ...c,
        payments: c.payments.map((p) =>
          ids.includes(p.no) && p.status === 'Pending Sync'
            ? { ...p, syncError: 'Network check failed. Saved on device; awaiting retry.' }
            : p
        ),
      }));
    } finally {
      setSyncing(false);
      setSyncingIds([]);
    }
  }, [ready, syncing, ledger.manualOffline, ledger.payments, saveToVault]);

  // Initial load from IndexedDB AES-GCM vault
  useEffect(() => {
    accessVault()
      .then((loaded) => {
        setLedger(loaded);
        setReady(true);
        if (!loaded.manualOffline && navigator.onLine) {
          setTimeout(() => {
            void triggerSync();
          }, 300);
        }
      })
      .catch((err) => {
        console.error('Initial vault load error:', err);
        setSaveError('Saved payments could not be securely decrypted. Device ledger paused.');
      });
  }, [triggerSync]);

  // Online / offline event listeners
  useEffect(() => {
    const handleOnline = () => {
      setConnected(true);
      if (!ledger.manualOffline) {
        void triggerSync();
      }
    };
    const handleOffline = () => {
      setConnected(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Auto-sync heartbeat every 15 seconds
    const interval = setInterval(() => {
      if (navigator.onLine && !ledger.manualOffline) {
        void triggerSync();
      }
    }, 15000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [ledger.manualOffline, triggerSync]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && screen !== 'search') {
        navigateBack();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screen, navigateBack]);

  // Toggle manual offline mode
  const handleToggleOffline = async (checked: boolean) => {
    playKeyClick();
    const ok = await saveToVault((c) => ({ ...c, manualOffline: checked }));
    if (ok && !checked && navigator.onLine) {
      void triggerSync();
    }
  };

  // Payment navigation handlers
  const handleStartPayment = () => {
    setAmount('');
    setAmountError('');
    navigateTo('collect');
  };

  const handleContinuePayment = () => {
    playKeyClick();
    const num = Number(amount);
    const reserved = reservedAmount(ledger.payments, currentFacility.no);
    const err = validatePaymentAmount(num, currentFacility.balance, reserved);
    if (err) {
      setAmountError(err);
      return;
    }
    setAmountError('');
    setShowConfirmModal(true);
  };

  const handleConfirmPayment = async () => {
    if (!ready || saving) return;
    const num = Number(amount);
    const reserved = reservedAmount(ledger.payments, currentFacility.no);
    const err = validatePaymentAmount(num, currentFacility.balance, reserved);
    if (err) {
      setAmountError(err);
      setShowConfirmModal(false);
      return;
    }

    setSaving(true);
    const newReceiptId = 'RC-' + crypto.randomUUID();
    const now = new Date();

    const newPayment: StoredPayment = {
      no: newReceiptId,
      facilityNo: currentFacility.no,
      customerId: currentCustomer.id,
      date: now.toLocaleString('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      }),
      historyDate: now.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
      amount: num,
      status: 'Pending Sync',
      savedAt: now.toISOString(),
      attempts: 0,
    };

    const ok = await saveToVault((c) => ({
      ...c,
      payments: [...c.payments, newPayment],
    }));

    setSaving(false);
    if (ok) {
      setShowConfirmModal(false);
      playSuccessChime();
      setActiveReceiptNo(newReceiptId);
      navigateTo('receipt');

      // If online and not in manual offline mode, attempt immediate sync in background
      if (connected && !ledger.manualOffline) {
        setTimeout(() => {
          void triggerSync();
        }, 800);
      }
    }
  };

  // Find active receipt object
  const activePayment = useMemo(() => {
    return ledger.payments.find((p) => p.no === activeReceiptNo);
  }, [ledger.payments, activeReceiptNo]);

  // Calculate remaining balance for active receipt
  const activeReceiptRemaining = useMemo(() => {
    if (!activePayment) return currentFacility.balance;
    const initialFac = INITIAL_FACILITIES.find((x) => x.no === activePayment.facilityNo);
    const baseBalance = initialFac ? initialFac.balance : 0;
    const pIdx = ledger.payments.findIndex((p) => p.no === activePayment.no);
    const paymentsPriorAndCurrent = ledger.payments.slice(0, pIdx + 1);
    const alreadyConfirmed = confirmedAmount(paymentsPriorAndCurrent, activePayment.facilityNo);
    return Math.max(0, baseBalance - alreadyConfirmed);
  }, [activePayment, ledger.payments, currentFacility.balance]);

  const isOfflineMode = ledger.manualOffline || !connected;

  return (
    <div className="min-h-screen bg-[#e9eef6] text-[#172b4d] flex flex-col justify-between selection:bg-[#2474e8] selection:text-white">
      {/* Top Desktop Helper Toolbar (Hidden on mobile / print) */}
      <div className="no-print hidden sm:flex items-center justify-between px-6 py-2 bg-[#14233d] text-white/80 text-xs border-b border-[#20375e]">
        <div className="flex items-center gap-2">
          <span className="font-bold text-white tracking-wide">◈ EAGLE CREDIT (PVT) LTD</span>
          <span className="text-slate-400">|</span>
          <span>Field Collection &amp; POS Mobile Terminal</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 bg-white/10 px-2 py-1 rounded text-[11px]">
            <span>Vault:</span>
            <span className="text-emerald-400 font-semibold">AES-GCM-256</span>
          </div>
          <button
            onClick={() => setPhoneFrame((p) => !p)}
            className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 px-2.5 py-1 rounded text-white font-medium transition-colors cursor-pointer"
          >
            {phoneFrame ? <Monitor size={13} /> : <Smartphone size={13} />}
            <span>{phoneFrame ? 'Expand Layout' : 'Handheld Frame'}</span>
          </button>
        </div>
      </div>

      {/* Main Terminal Frame */}
      <div
        className={`w-full mx-auto my-0 transition-all ${
          phoneFrame
            ? 'sm:my-6 sm:max-w-[430px] sm:rounded-3xl sm:shadow-2xl sm:border sm:border-slate-300 sm:overflow-hidden bg-[#f5f8fc]'
            : 'max-w-2xl sm:my-6 sm:rounded-2xl sm:shadow-xl sm:border sm:border-slate-300 bg-[#f5f8fc]'
        }`}
      >
        <Header
          screen={screen}
          onBack={navigateBack}
          ledger={ledger}
          connected={connected}
          ready={ready}
          syncing={syncing}
          onToggleOffline={handleToggleOffline}
          onOpenSyncStatus={() => navigateTo('sync-status')}
          onTriggerSync={triggerSync}
          saveError={saveError}
        />

        <main className="p-4 sm:p-5 min-h-[580px]">
          {screen === 'search' && (
            <SearchScreen
              customers={CUSTOMERS}
              facilities={currentFacilities}
              onSelectCustomer={(c) => {
                setSelectedCustomerId(c.id);
                navigateTo('profile');
              }}
            />
          )}

          {screen === 'profile' && (
            <ProfileScreen
              customer={currentCustomer}
              facilities={currentFacilities.filter((f) => f.customerId === currentCustomer.id)}
              onSelectFacility={(f) => {
                setSelectedFacilityNo(f.no);
                navigateTo('facility');
              }}
            />
          )}

          {screen === 'facility' && (
            <FacilityScreen
              facility={currentFacility}
              onViewGuarantors={() => navigateTo('guarantors')}
              onViewAsset={() => navigateTo('asset')}
              onViewHistory={() => navigateTo('history')}
              onStartPayment={handleStartPayment}
            />
          )}

          {screen === 'guarantors' && (
            <GuarantorsScreen
              facility={currentFacility}
              guarantors={currentGuarantors}
              onBack={navigateBack}
            />
          )}

          {screen === 'asset' && (
            <AssetScreen facility={currentFacility} onBack={navigateBack} />
          )}

          {screen === 'history' && (
            <HistoryScreen
              facility={currentFacility}
              storedPayments={ledger.payments}
              initialHistory={INITIAL_HISTORY[currentFacility.no] || []}
              onViewReceipt={(rcId) => {
                setActiveReceiptNo(rcId);
                navigateTo('receipt');
              }}
              onStartPayment={handleStartPayment}
            />
          )}

          {screen === 'collect' && (
            <CollectScreen
              customer={currentCustomer}
              facility={currentFacility}
              amount={amount}
              amountError={amountError}
              queuedReserved={reservedAmount(ledger.payments, currentFacility.no)}
              ready={ready}
              onAmountChange={(val) => {
                setAmount(val);
                setAmountError('');
              }}
              onContinue={handleContinuePayment}
              onBack={navigateBack}
            />
          )}

          {screen === 'confirm' && (
            <ConfirmScreen
              customer={currentCustomer}
              facility={currentFacility}
              amount={Number(amount)}
              isOffline={isOfflineMode}
              saving={saving}
              ready={ready}
              onConfirm={handleConfirmPayment}
              onCancel={navigateBack}
            />
          )}

          {screen === 'receipt' && activePayment && (
            <ReceiptScreen
              payment={activePayment}
              customer={
                CUSTOMERS.find((c) => c.id === activePayment.customerId) || currentCustomer
              }
              facility={
                currentFacilities.find((f) => f.no === activePayment.facilityNo) ||
                currentFacility
              }
              remainingBalance={activeReceiptRemaining}
              onReturnToProfile={() => {
                setStack([]);
                setScreen('profile');
              }}
              onCollectAnother={handleStartPayment}
            />
          )}

          {screen === 'sync-status' && (
            <SyncStatusScreen
              payments={ledger.payments}
              customers={CUSTOMERS}
              facilities={currentFacilities}
              filter={syncFilter}
              ready={ready}
              syncing={syncing}
              syncingIds={syncingIds}
              isOffline={isOfflineMode}
              onFilterChange={setSyncFilter}
              onRetrySync={triggerSync}
              onViewReceipt={(facNo, rcNo) => {
                setSelectedFacilityNo(facNo);
                setActiveReceiptNo(rcNo);
                navigateTo('receipt');
              }}
            />
          )}
        </main>

        {/* Payment Confirmation Popup Modal */}
        <ConfirmModal
          isOpen={showConfirmModal}
          customer={currentCustomer}
          facility={currentFacility}
          amount={Number(amount)}
          isOffline={isOfflineMode}
          saving={saving}
          ready={ready}
          onConfirm={handleConfirmPayment}
          onCancel={() => setShowConfirmModal(false)}
        />
      </div>

      {/* Footer copyright note */}
      <footer className="no-print py-4 text-center text-xs text-[#7183a3]">
        Eagle Credit (PVT) LTD · Secure Field Operations Terminal
      </footer>
    </div>
  );
}
