import { Ledger, StoredPayment } from '../types';

const DB_NAME = 'eagle-credit-secure-payments';
const STORE_NAME = 'vault';
const LEGACY_KEY = 'eagle-credit-demo-payments-v1';
const AAD = new TextEncoder().encode(DB_NAME);

export const emptyLedger = (): Ledger => ({
  version: 1,
  manualOffline: false,
  payments: [],
});

export function validLedger(l: unknown): Ledger {
  if (
    !l ||
    typeof l !== 'object' ||
    (l as Ledger).version !== 1 ||
    typeof (l as Ledger).manualOffline !== 'boolean' ||
    !Array.isArray((l as Ledger).payments)
  ) {
    throw new Error('Invalid ledger schema');
  }
  return l as Ledger;
}

const req = <T>(r: IDBRequest<T>): Promise<T> =>
  new Promise((res, rej) => {
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

const completed = (tx: IDBTransaction): Promise<void> =>
  new Promise((res, rej) => {
    tx.oncomplete = () => res();
    tx.onabort = () => rej(tx.error || new Error('Transaction aborted'));
    tx.onerror = () => rej(tx.error);
  });

async function openDb(): Promise<IDBDatabase> {
  if (!window.indexedDB) {
    throw new Error('IndexedDB unavailable');
  }
  const openReq = indexedDB.open(DB_NAME, 1);
  openReq.onupgradeneeded = () => {
    const db = openReq.result;
    if (!db.objectStoreNames.contains(STORE_NAME)) {
      db.createObjectStore(STORE_NAME);
    }
  };
  return req(openReq);
}

interface SealedPayload {
  version: 1;
  iv: Uint8Array;
  ciphertext: ArrayBuffer;
}

async function seal(ledger: Ledger, key: CryptoKey): Promise<SealedPayload> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(JSON.stringify(validLedger(ledger)));
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: AAD },
    key,
    encoded
  );
  return { version: 1, iv, ciphertext };
}

async function unseal(sealed: SealedPayload, key: CryptoKey): Promise<Ledger> {
  if (sealed.version !== 1) {
    throw new Error('Unsupported vault format');
  }
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: sealed.iv as unknown as BufferSource, additionalData: AAD },
    key,
    sealed.ciphertext
  );
  const jsonStr = new TextDecoder().decode(decrypted);
  return validLedger(JSON.parse(jsonStr));
}

// Fallback memory / localStorage storage in case crypto or IDB is restricted in restrictive sandboxes
function readLocalStorageFallback(): Ledger {
  try {
    const raw = localStorage.getItem(LEGACY_KEY);
    if (raw) return validLedger(JSON.parse(raw));
  } catch {
    // Ignore fallback errors
  }
  return emptyLedger();
}

function writeLocalStorageFallback(ledger: Ledger) {
  try {
    localStorage.setItem(LEGACY_KEY, JSON.stringify(validLedger(ledger)));
  } catch {
    // Ignore fallback errors
  }
}

export async function accessVault(transform?: (current: Ledger) => Ledger): Promise<Ledger> {
  const canUseCrypto = typeof window !== 'undefined' && window.crypto && window.crypto.subtle && window.indexedDB;

  if (!canUseCrypto) {
    const current = readLocalStorageFallback();
    const updated = transform ? validLedger(transform(current)) : current;
    if (transform) writeLocalStorageFallback(updated);
    return updated;
  }

  const runWithDb = async (): Promise<Ledger> => {
    let db: IDBDatabase | null = null;
    try {
      db = await openDb();
      const rtx = db.transaction(STORE_NAME, 'readonly');
      const rDone = completed(rtx);
      const store = rtx.objectStore(STORE_NAME);
      const [key, sealed] = await Promise.all([
        req(store.get('key') as IDBRequest<CryptoKey | undefined>),
        req(store.get('ledger') as IDBRequest<SealedPayload | undefined>),
      ]);
      await rDone;

      let loaded: Ledger;
      if (sealed && key) {
        loaded = await unseal(sealed, key);
      } else {
        loaded = readLocalStorageFallback();
      }

      const dk: CryptoKey =
        key ||
        (await crypto.subtle.generateKey(
          { name: 'AES-GCM', length: 256 },
          false,
          ['encrypt', 'decrypt']
        ));

      const next = transform ? validLedger(transform(loaded)) : loaded;

      if (transform || !sealed || !key) {
        const blob = await seal(next, dk);
        const wtx = db.transaction(STORE_NAME, 'readwrite');
        const wDone = completed(wtx);
        const wStore = wtx.objectStore(STORE_NAME);
        wStore.put(dk, 'key');
        wStore.put(blob, 'ledger');
        await wDone;
      }

      // Cleanup any legacy unencrypted item
      try {
        localStorage.removeItem(LEGACY_KEY);
      } catch {
        // ignore
      }

      return next;
    } catch (err) {
      console.warn('Encrypted vault fallback activated:', err);
      const current = readLocalStorageFallback();
      const updated = transform ? validLedger(transform(current)) : current;
      if (transform) writeLocalStorageFallback(updated);
      return updated;
    } finally {
      if (db) {
        db.close();
      }
    }
  };

  if (typeof navigator !== 'undefined' && navigator.locks && navigator.locks.request) {
    try {
      return await navigator.locks.request(DB_NAME, runWithDb);
    } catch {
      return await runWithDb();
    }
  }

  return await runWithDb();
}

export function confirmedAmount(payments: StoredPayment[], facilityNo: string): number {
  return payments
    .filter((p) => p.facilityNo === facilityNo && p.status === 'Confirmed')
    .reduce((sum, p) => sum + p.amount, 0);
}

export function reservedAmount(payments: StoredPayment[], facilityNo: string): number {
  return payments
    .filter((p) => p.facilityNo === facilityNo && p.status === 'Pending Sync')
    .reduce((sum, p) => sum + p.amount, 0);
}

export function confirmQueued(ledger: Ledger, ids: string[], at = new Date().toISOString()): Ledger {
  return {
    ...ledger,
    payments: ledger.payments.map((p) =>
      ids.includes(p.no) && p.status === 'Pending Sync'
        ? { ...p, status: 'Confirmed', syncedAt: at, syncError: undefined }
        : p
    ),
  };
}

export function recordAttempt(ledger: Ledger, ids: string[], at: string, err?: string): Ledger {
  return {
    ...ledger,
    payments: ledger.payments.map((p) =>
      ids.includes(p.no) && p.status === 'Pending Sync'
        ? {
            ...p,
            attempts: (p.attempts || 0) + 1,
            lastAttemptAt: at,
            syncError: err,
          }
        : p
    ),
  };
}

export function validatePaymentAmount(amount: number, balance: number, pendingReserve: number): string | null {
  if (!Number.isFinite(amount) || amount <= 0 || Math.abs(amount * 100 - Math.round(amount * 100)) > 1e-6) {
    return 'Enter a valid amount greater than zero with at most two decimal places.';
  }
  if (Math.round(amount * 100) > Math.round((balance - pendingReserve) * 100)) {
    return 'Amount exceeds the available balance after queued payments.';
  }
  return null;
}
