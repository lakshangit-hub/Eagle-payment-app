import React, { useState } from 'react';
import { Customer, Facility, StoredPayment } from '../types';
import { formatMoney } from '../utils/format';
import { Printer, UserCheck, Check, Copy } from 'lucide-react';
import { playKeyClick, playPrintWhirr } from '../utils/audio';

interface ReceiptScreenProps {
  payment: StoredPayment;
  customer: Customer;
  facility: Facility;
  remainingBalance: number;
  onReturnToProfile: () => void;
  onCollectAnother: () => void;
}

export const ReceiptScreen: React.FC<ReceiptScreenProps> = ({
  payment,
  customer,
  facility,
  remainingBalance,
  onReturnToProfile,
  onCollectAnother,
}) => {
  const [copied, setCopied] = useState(false);

  const handlePrint = () => {
    playPrintWhirr();
    try {
      window.print();
    } catch {
      // Ignore
    }
  };

  const handleCopy = () => {
    playKeyClick();
    const text = `EAGLE CREDIT (PVT) LTD - PAYMENT RECEIPT
Receipt No: ${payment.no}
Date: ${payment.date}
Customer: ${customer.name} (${customer.id})
Facility: ${facility.no} - ${facility.product}
Maturity Date: ${facility.maturity}
Amount: ${formatMoney(payment.amount)}
Status: ${payment.status}
Remaining Balance: ${formatMoney(remainingBalance)}`;

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {});
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      <div className="no-print">
        <div className="text-[11px] font-bold uppercase tracking-wider text-[#7183a3] mb-1">
          58 mm Thermal Receipt
        </div>
        <h1 className="text-2xl font-bold text-[#172b4d] tracking-tight">Receipt Preview</h1>
      </div>

      {/* 58mm Thermal Slip Design */}
      <div className="relative">
        {/* Receipt paper container */}
        <div className="print-receipt-container w-full max-w-[300px] mx-auto bg-white text-[#111111] p-4.5 rounded-sm border border-dashed border-[#b0bccb] shadow-md font-mono-receipt text-[11px] leading-[1.45] select-text">
          {/* Top Header */}
          <div className="text-center pb-2">
            <div className="text-base font-black tracking-wider uppercase">EAGLE CREDIT (PVT) LTD</div>
            <div className="font-extrabold text-[12px] tracking-wider mt-0.5">PAYMENT RECEIPT</div>
            <div className="text-[9px] text-[#555] mt-0.5">Microfinance &amp; Leasing Division</div>
          </div>

          <div className="border-t border-dashed border-[#555] my-2"></div>

          {/* Metadata */}
          <div className="space-y-0.5">
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Receipt No:</span>
              <span className="font-bold text-right truncate max-w-[170px]">{payment.no}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Date &amp; Time:</span>
              <span className="text-right font-medium">{payment.date}</span>
            </div>
          </div>

          <div className="border-t border-dashed border-[#555] my-2"></div>

          {/* Customer */}
          <div className="font-bold text-[10px] tracking-wide text-[#333] mb-1 uppercase">
            Customer Details
          </div>
          <div className="space-y-0.5">
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Name:</span>
              <span className="font-bold text-right">{customer.name}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Customer ID:</span>
              <span className="text-right">{customer.id}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">NIC:</span>
              <span className="text-right">{customer.nic}</span>
            </div>
          </div>

          <div className="border-t border-dashed border-[#555] my-2"></div>

          {/* Facility */}
          <div className="font-bold text-[10px] tracking-wide text-[#333] mb-1 uppercase">
            Facility Details
          </div>
          <div className="space-y-0.5">
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Facility No:</span>
              <span className="font-bold text-right">{facility.no}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Product:</span>
              <span className="text-right">{facility.product}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-[#444]">Maturity Date:</span>
              <span className="text-right">{facility.maturity}</span>
            </div>
            {facility.arrears > 0 && (
              <div className="flex justify-between gap-2 text-rose-700">
                <span>Arrears:</span>
                <span className="font-bold text-right">{formatMoney(facility.arrears)}</span>
              </div>
            )}
            {facility.asset && facility.vehicle && (
              <div className="flex justify-between gap-2">
                <span className="text-[#444]">Vehicle No:</span>
                <span className="font-bold text-right">{facility.vehicle}</span>
              </div>
            )}
          </div>

          <div className="border-t border-dashed border-[#555] my-2"></div>

          {/* Payment */}
          <div className="font-bold text-[10px] tracking-wide text-[#333] mb-1 uppercase">
            Payment Details
          </div>
          <div className="space-y-1">
            <div className="flex justify-between gap-2 text-sm font-black pt-0.5">
              <span>Amount Received:</span>
              <span className="text-right">{formatMoney(payment.amount)}</span>
            </div>

            {payment.status === 'Pending Sync' ? (
              <div className="border border-black p-1.5 my-1 text-center font-bold text-[10px] uppercase leading-tight bg-slate-50">
                PENDING SYNC
                <br />
                <span className="text-[9px] font-normal">Stored on field device</span>
              </div>
            ) : (
              <div className="flex justify-between gap-2 pt-0.5">
                <span className="text-[#444]">Remaining Balance:</span>
                <span className="font-bold text-right">{formatMoney(remainingBalance)}</span>
              </div>
            )}

            <div className="flex justify-between gap-2 text-[10px] text-[#555] pt-1">
              <span>Collected by:</span>
              <span>Field Officer #402</span>
            </div>
          </div>

          <div className="border-t border-dashed border-[#555] my-2"></div>

          {/* Footer note */}
          <div className="text-center space-y-0.5 text-[9.5px] text-[#444] pt-1">
            <div className="font-bold text-[#111]">Thank you for your payment.</div>
            <div>Please keep this receipt for your records.</div>
            <div className="text-[9px] text-[#666] pt-1 font-semibold uppercase tracking-wider">
              Eagle Credit (PVT) LTD — Customer Copy
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons (Hidden on Print) */}
      <div className="no-print space-y-2.5 pt-2">
        <button
          onClick={handlePrint}
          className="w-full py-3.5 px-4 bg-[#2474e8] hover:bg-[#1c62cb] active:scale-[0.99] text-white font-bold rounded-xl shadow-md shadow-[#2474e8]/20 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
        >
          <Printer size={18} />
          <span>Print Receipt</span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleCopy}
            className="py-2.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-[#172b4d] font-semibold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            {copied ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>

          <button
            onClick={() => {
              playKeyClick();
              onReturnToProfile();
            }}
            className="py-2.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-[#172b4d] font-semibold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <UserCheck size={14} />
            <span>Customer Profile</span>
          </button>
        </div>

        <div className="text-[10px] text-[#7183a3] text-center pt-1 leading-relaxed">
          Printing uses your browser’s print dialog formatted for 58mm thermal printers. Actual Sunmi / Pax POS hardware integration is simulated.
        </div>
      </div>
    </div>
  );
};
